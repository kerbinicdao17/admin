<div class="header">
  <h1 style="text-size: 10px;">Admin's Dashboard</h1>
  <div class="admin-info">
    <span>👤 Admin</span>
    <a href="logout.php" class="logout-btn">Logout</a>
  </div>
</div>
