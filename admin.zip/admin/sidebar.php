<div class="sidebar">
  <img href="pic.jpg" alt="admin-pic">
  <h3>Administrator</h3>
</br>
  <h2>Admin Panel</h2>
  <a href="dashboard.php">🏠 Dashboard</a>
  <a href="products.php">📦 Products</a>
  <a href="orders.php">🧾 Orders</a>
  <a href="customers.php">👥 Customers</a>
  <a href="reports.php">📊 Reports</a>
  <a href="logout.php">🚪 Logout</a>
</div>
